/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tracfin;

/**
 *
 * @author GSEYRA
 */
public class VersionDetails {
     
      public void showCurrentVersion(){
            /*V 1*/
            System.out.println("Version 1.0 du GenCSV");
           
      }
 
}
