package template.types;

public class File {
	
String path;
String type;
String startPosition;
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getStartPosition() {
	return startPosition;
}
public void setStartPosition(String startPosition) {
	this.startPosition = startPosition;
}
}
