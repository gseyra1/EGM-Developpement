package template.types;

public class input {

	File file;
}
