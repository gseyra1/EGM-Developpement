package templating.reader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

public class ReadTemplate {
	
public void getTemplate() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException{
	//crée un fichier txt qui contien ce qu'il ya en commentaire ci-dessou
	/*======
	 * <#list countries as country>
	${country_index + 1}. ${country}
		</#list>
	 */
	Configuration cfg = new Configuration();
	Template template = cfg.getTemplate("test.ftlh");
	Map<String, Object> data = new HashMap<String,Object>();
	data.put("message", "Hello World!");

	//List parsing 
	List<String> countries = new ArrayList<String>();
	countries.add("India");
	countries.add("United States");
	countries.add("Germany");
	countries.add("France");
	
	data.put("countries", countries);

	
	// Console output
	Writer out = new OutputStreamWriter(System.out);
	template.process(data, out);
	out.flush();

	// File output
	Writer file = new FileWriter(new File("C:\\FTL_helloworld.txt"));
	template.process(data, file);
	file.flush();
	file.close();
}

}
